package com.selfdeveloped.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPaginationSortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
